<?php $__env->startPush('customCss'); ?>
    <style>

    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('backendContent'); ?>
    <h2 class="fs-xl mt-3">All Posts</h2>

    <table class="table table-responsive">
        <tr>
            <th>#</th>
            <th>Featured Image</th>
            <th>Title</th>
            <th>Author</th>
            <th>Banner Status</th>
            <th>Actions</th>
        </tr>

        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e(++$key); ?></td>
                <td><img src="<?php echo e(setImage($post->featured_img)); ?>" alt="<?php echo e($post->title); ?>"
                        style="max-height: 120px;border-radius: 10px;">
                </td>
                <td><?php echo e($post->title); ?></td>
                <td><?php echo e($post->user->name); ?></td>
                <td>
                    <div class="d-flex gap-2 align-items-center">
                        <div>
                            <?php if($post->is_banner): ?>
                                <span
                                    style="background: rgb(95, 255, 47); padding:5px 10px; color:rgb(110, 110, 110);border-radius:5px;">Active</span>
                            <?php else: ?>
                                <span
                                    style="background: rgb(255, 230, 0); padding:5px 10px; color:gray;border-radius:5px;">Inactive</span>
                            <?php endif; ?>
                        </div>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('toggle post')): ?>
                            <form action="<?php echo e(route('post.toggleBanner', $post)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('patch'); ?>
                                <button type="submit" class="btn btn-dark btn-sm">Toggle</button>
                            </form>
                        <?php endif; ?>
                    </div>
                </td>
                <td>
                    <div class="d-flex gap-2">
                        <a href="<?php echo e(route('post.show', $post)); ?>" class="btn btn-dark btn-sm">View</a>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update post')): ?>
                            <a href="<?php echo e(route('post.edit', $post)); ?>" class="btn btn-primary btn-sm">Edit</a>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete post')): ?>
                            <form action="<?php echo e(route('post.destroy', $post)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                            </form>
                        <?php endif; ?>
                    </div>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('customJs'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backendapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mojahid/work-spaces/laravel/creative-it/laravel-project/blog-app/resources/views/backend/post/allPost.blade.php ENDPATH**/ ?>