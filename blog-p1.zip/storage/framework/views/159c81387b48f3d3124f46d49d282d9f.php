<?php $__env->startPush('customCss'); ?>
    <style>

    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('backendContent'); ?>
    <div class="card">
        <div class="card-header">Add Post</div>
        <div class="card-body " style="padding: 20px 40px">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create post')): ?>
                <form action="<?php echo e(route('post.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>


                    <div class="row">
                        <input type="text" name="title" placeholder="Post Title" class="form-control"
                            style=" margin: 10px 0;">
                        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span style="color:red"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="row">

                        <div class="col">
                            <select name="category_id" id="" class="form-control flex-grow-1" style=" margin: 10px 0;">
                                <option selected disabled>Select Category</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option class="category" value="<?php echo e($category->id); ?>"><?php echo e($category->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span style="color:red"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col">
                            <select name="sub_category_id" id="" class="form-control flex-grow-1"
                                style=" margin: 10px 0;">
                                <option selected disabled>Select SubCategory</option>
                                <?php $__currentLoopData = $subCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option class="subs-<?php echo e($subcategory->category_id); ?>"
                                        id="sub-<?php echo e($subcategory->category_id); ?>" value="<?php echo e($subcategory->id); ?>">
                                        <?php echo e($subcategory->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['sub_category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span style="color:red"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="col">
                            <select name="type" class="form-control" style=" margin: 10px 0;">
                                <option selected disabled>Select Type</option>
                                <option value="trending">Trending</option>
                                <option value="hot">Hot Topic</option>
                            </select>
                            <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span style="color:red"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>


                    </div>

                    <div class="row">
                        <label for="">
                            Featured Image
                            <input type="file" name="featured_img" class="form-control">
                            <?php $__errorArgs = ['featured_img'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span style="color:red"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </label>
                    </div>



                    <div class="editor" style="margin: 20px 0">
                        <textarea name="content" id="content" class="form-control" placeholder="Editor or Content Here"></textarea>
                        <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span style="color:red"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    

                    <button class="btn-primary btn" style="width:100%;margin:20px 0;">Submit</button>

                </form>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('customJs'); ?>
    <script src="https://cdn.ckeditor.com/ckeditor5/36.0.0/classic/ckeditor.js"></script>
    <script>
        ClassicEditor
            .create(document.querySelector('#content'))
            .catch(error => {
                console.error(error);
            });

        //hide subcategories when selected category
        const category = $("[name='category_id']");
        category.change(function(e) {
            $("[class*='subs-']").show() //show every options
            console.log('changed');
            const sub = $("[class*='subs-']").not(
                `.subs-${e.target.value}`); //select options that is not related to the category
            sub.hide() //hide them

        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backendapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mojahid/work-spaces/laravel/creative-it/laravel-project/blog-app/resources/views/backend/post/addPost.blade.php ENDPATH**/ ?>