<?php $__env->startSection('backendContent'); ?>
    <div class="col-lg-6 mt-5 mx-auto">
        <div class="card">
            <div class="card-header">Add New Role</div>
            <div class="card-body">
                <form action="<?php echo e(route('role.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input class="form-control" type="text" name="role">
                    <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger">
                            <?php echo e($message); ?>

                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <button class="btn btn-primary" style="width:100%; margin-top: 15px;">Submit</button>
                </form>
            </div>
        </div>
    </div>


    <div class="mt-5">
        <table class="table table-responsive">
            <tr>
                <th>#</th>
                <th>Role Name</th>
                <th>Actions</th>
            </tr>

            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e(++$key); ?></td>
                    <td><?php echo e($role->name); ?></td>
                    <td>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update role')): ?>
                            <a href="<?php echo e(route('role.edit', $role)); ?>" class="btn btn-primary btn-sm">Edit</a>
                        <?php endif; ?>

                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backendapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mojahid/work-spaces/laravel/creative-it/laravel-project/blog-app/resources/views/backend/roles/addRoles.blade.php ENDPATH**/ ?>