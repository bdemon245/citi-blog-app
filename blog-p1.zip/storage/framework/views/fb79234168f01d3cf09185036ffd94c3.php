<?php $__env->startSection('backendContent'); ?>
<h2>Welcome To Dashboard</h2>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backendapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mojahid/work-spaces/laravel/creative-it/laravel-project/blog-app/resources/views/backend/dashboard.blade.php ENDPATH**/ ?>