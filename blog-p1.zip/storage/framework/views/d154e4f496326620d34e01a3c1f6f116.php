<?php if($paginator->hasPages()): ?>
    <nav role="navigation" aria-label="<?php echo e(__('Pagination Navigation')); ?>" class="f">
        

        
        <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <ul class="pagination justify-content-center">
                <?php if(is_array($element)): ?>
                    <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($page == $paginator->currentPage()): ?>
                            <li aria-current="page" class="page-item active">
                                <span class="page-link"><?php echo e($page); ?></span>
                            </li>
                        <?php else: ?>
                            <li class="page-item">
                                <a href="<?php echo e($url); ?>" class="page-link"
                                    aria-label="<?php echo e(__('Go to page :page', ['page' => $page])); ?>"><?php echo e($page); ?>

                                </a>
                            </li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </ul>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <div class="d-flex align-items-center justify-content-between px-5 mt-2">
            <p class="ms-3">
                <?php echo __('Showing'); ?>

                <?php if($paginator->firstItem()): ?>
                    <span class=""><?php echo e($paginator->firstItem()); ?></span>
                    <?php echo __('to'); ?>

                    <span class=""><?php echo e($paginator->lastItem()); ?></span>
                <?php else: ?>
                    <?php echo e($paginator->count()); ?>

                <?php endif; ?>
                <?php echo __('of'); ?>

                <span class=""><?php echo e($paginator->total()); ?></span>
                <?php echo __('results'); ?>

            </p>
            
            <div class="d-flex gap-2">
                
                <div class="">
                    <?php if(!$paginator->onFirstPage()): ?>
                        <a href="<?php echo e($paginator->previousPageUrl()); ?>" class="btn btn-dark">
                            <?php echo __('pagination.previous'); ?>

                        </a>
                    <?php endif; ?>
                </div>
                
                <div class="">
                    <?php if($paginator->hasMorePages()): ?>
                        <a href="<?php echo e($paginator->nextPageUrl()); ?>" class="btn btn-default">
                            <?php echo __('pagination.next'); ?>

                        </a>
                    <?php endif; ?>
                </div>
            </div>

        </div>

    </nav>
<?php endif; ?>
<?php /**PATH /home/mojahid/work-spaces/laravel/creative-it/laravel-project/blog-app/resources/views/vendor/pagination/custom.blade.php ENDPATH**/ ?>