<?php
    function isChecked($hasPermissions, $permissionId)
    {
        $value = false;
        if ($hasPermissions->search($permissionId) !== false) {
            $value = true;
        }
        return $value;
    }
?>
<?php $__env->startSection('backendContent'); ?>
    <div class="col-lg-6 mt-5 mx-auto">
        <div class="card">
            <div class="card-header">Edit Role</div>
            <div class="card-body">
                <form action="<?php echo e(route('role.update', $role)); ?>" method="POST">
                    <?php echo method_field('PUT'); ?>
                    <?php echo csrf_field(); ?>
                    <input class="form-control" type="text" name="role" value="<?php echo e($role->name); ?>">
                    <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger">
                            <?php echo e($message); ?>

                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <button class="btn btn-primary" style="width:100%; margin-top: 15px;">Update Role & Permission</button>

            </div>
        </div>
    </div>


    <div class="card">
        <div class="card-header">


            <h5>All Permissions</h5>



        </div>
    </div>
    <div class="card-body">

        <div class="row">
            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-3 form-check form-switch" style="margin: 12px 0;">

                    <input class="form-check-input" type="checkbox" role="switch" name="permissions[]"
                        id="permission_<?php echo e($permission->id); ?>" value="<?php echo e($permission->id); ?>"
                        <?php echo e(isChecked($hasPermissions, $permission->id) ? 'checked' : ''); ?>>
                    <label class="form-check-label" for="permission_<?php echo e($permission->id); ?>">
                        <h4><strong><?php echo e(str()->headline($permission->name)); ?></strong></h4>
                    </label>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>


    </div>
    </div>

    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backendapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mojahid/work-spaces/laravel/creative-it/laravel-project/blog-app/resources/views/backend/roles/editRole.blade.php ENDPATH**/ ?>