<ul>
    <li>
        <a href="<?php echo e(route('dashboard')); ?>"
            class="side-menu <?php echo e(request()->routeIs('dashboard') ? 'side-menu--active side-menu--open' : ''); ?>">
            <div class="side-menu__icon"> <i data-feather="home"></i> </div>
            <div class="side-menu__title">
                Dashboard

            </div>
        </a>

    </li>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create role')): ?>
        <li>
            <a href="<?php echo e(route('role.index')); ?>"
                class="side-menu <?php echo e(request()->routeIs('role.*') ? 'side-menu--active side-menu--open' : ''); ?>">
                <div class="side-menu__icon"> <i data-feather="home"></i> </div>
                <div class="side-menu__title">
                    Role Management

                </div>
            </a>

        </li>
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create user')): ?>
        <li>
            <a href="<?php echo e(route('user.index')); ?>" class="side-menu">
                <div class="side-menu__icon"> <i data-feather="home"></i> </div>
                <div class="side-menu__title">
                    User Management

                </div>
            </a>

        </li>
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['read category', 'read sub_category'])): ?>
        <li>
            <a href="javascript:;"
                class="side-menu  <?php echo e(request()->routeIs('category.*') | request()->routeIs('subCategory.*') ? 'side-menu--active side-menu--open' : ''); ?>">
                <div class="side-menu__icon"> <i data-feather="folder"></i> </div>
                <div class="side-menu__title">
                    Category
                    <div class="side-menu__sub-icon"> <i data-feather="chevron-down"></i> </div>
                </div>
            </a>
            <ul
                class="<?php echo e(request()->routeIs('category.*') | request()->routeIs('subCategory.*') ? 'side-menu__sub-open' : ''); ?>">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create category')): ?>
                    <li>
                        <a href="<?php echo e(route('category.index')); ?>" class="side-menu side-menu--active side-menu--open">
                            <div class="side-menu__icon"> <i data-feather="activity"></i> </div>
                            <div class="side-menu__title"> Category Manegment </div>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create sub_category')): ?>
                    <li>
                        <a href="<?php echo e(route('subCategory.index')); ?>" class="side-menu side-menu--active side-menu--open">
                            <div class="side-menu__icon"> <i data-feather="activity"></i> </div>
                            <div class="side-menu__title"> Sub-Category Manegment </div>
                        </a>
                    </li>
                <?php endif; ?>

            </ul>
        </li>
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('read post')): ?>
        <li>
            <a href="javascript:;"
                class="side-menu  <?php echo e(request()->routeIs('post.*') ? 'side-menu--active side-menu--open' : ''); ?>">
                <div class="side-menu__icon"> <i data-feather="folder"></i> </div>
                <div class="side-menu__title">
                    Post
                    <div class="side-menu__sub-icon"> <i data-feather="chevron-down"></i> </div>
                </div>
            </a>
            <ul class="<?php echo e(request()->routeIs('post.*') ? 'side-menu__sub-open' : ''); ?>">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create post')): ?>
                    <li>
                        <a href="<?php echo e(route('post.create')); ?>" class="side-menu side-menu--active side-menu--open">
                            <div class="side-menu__icon"> <i data-feather="activity"></i> </div>
                            <div class="side-menu__title"> Add Post</div>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('read post')): ?>
                    <li>
                        <a href="<?php echo e(route('post.index')); ?>" class="side-menu side-menu--active side-menu--open">
                            <div class="side-menu__icon"> <i data-feather="activity"></i> </div>
                            <div class="side-menu__title"> View All Posts </div>
                        </a>
                    </li>
                <?php endif; ?>
            </ul>
        </li>
    <?php endif; ?>


</ul>
<?php /**PATH /home/mojahid/work-spaces/laravel/creative-it/laravel-project/blog-app/resources/views/layouts/backendSidebar.blade.php ENDPATH**/ ?>