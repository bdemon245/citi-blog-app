<?php
    function readMore($post)
    {
        $value = "<a href='/post/$post->id' style='color: var(--bs-red);'>...Read More</a>";
        return $value;
    }
?>
<?php $__env->startSection('content'); ?>
    <section class="page-header">
        <div class="container-xl">
            <div class="text-center">
                <h1 class="mt-0 mb-2"><?php echo e(str()->headline($category->title)); ?></h1>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb justify-content-center mb-0">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('frontend.home')); ?>">Home</a>
                        </li>

                        <?php if(isset($category->subCategories)): ?>
                            <li class="breadcrumb-item active" aria-current="page">
                                <a
                                    href="<?php echo e(route('frontend.category', $category->id)); ?>"><?php echo e(str()->headline($category->title)); ?></a>
                            </li>
                        <?php else: ?>
                            <li class="breadcrumb-item" aria-current="page">
                                <a href="<?php echo e(route('frontend.category', $category->category->id)); ?>">
                                    <?php echo e(str()->headline($category->category->title)); ?>

                                </a>
                            </li>
                            <li class="breadcrumb-item active" aria-current="page">
                                <a href="<?php echo e(route('frontend.category', $category->id)); ?>">
                                    <?php echo e(str()->headline($category->title)); ?>

                                </a>
                            </li>
                        <?php endif; ?>

                    </ol>
                </nav>
            </div>
        </div>
    </section>

    <!-- section main content -->
    <section class="main-content">
        <div class="container-xl">

            <div class="row gy-4">

                <div class="col-lg-8">

                    <div class="row gy-4">

                        <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="col-sm-6">
                                <!-- post -->
                                <div class="post post-grid rounded bordered">
                                    <div class="thumb top-rounded">
                                        <?php if(isset($post->type)): ?>
                                            <a href="<?php echo e(route('frontend.show', $post)); ?>"
                                                class="category-badge position-absolute"><?php echo e($post->type); ?></a>
                                        <?php endif; ?>
                                        <a href="<?php echo e(route('frontend.show', $post)); ?>">
                                            <div class="inner">
                                                <img src="<?php echo e(setImage($post->featured_img)); ?>"
                                                    alt="<?php echo e($post->slug); ?>" />
                                            </div>
                                        </a>
                                    </div>
                                    <div class="details">
                                        <ul class="meta list-inline mb-0">
                                            <li class="list-inline-item"><a href="<?php echo e(route('frontend.show', $post)); ?>"><img
                                                        src="<?php echo e(setImage($post->user->avatar)); ?>" class="author avatar"
                                                        alt="author" /><?php echo e($post->user->name); ?></a></li>
                                            <li class="list-inline-item">
                                                <?php echo e(Carbon\Carbon::parse($post->created_at)->format('d M Y')); ?>

                                            </li>
                                        </ul>
                                        <h5 class="post-title mb-3 mt-3">
                                            <a href="<?php echo e(route('frontend.show', $post)); ?>"><?php echo e($post->title); ?></a>
                                        </h5>
                                        <p class="excerpt mb-0">
                                            <?php echo Str::limit($post->content, 100, readMore($post)); ?>

                                        </p>
                                    </div>
                                    <div class="post-bottom clearfix d-flex align-items-center">
                                        <div class="social-share me-auto">
                                            <button class="toggle-button icon-share"></button>
                                            <ul class="icons list-unstyled list-inline mb-0">
                                                <li class="list-inline-item"><a href="category.html#"><i
                                                            class="fab fa-facebook-f"></i></a></li>
                                                <li class="list-inline-item"><a href="category.html#"><i
                                                            class="fab fa-twitter"></i></a></li>
                                                <li class="list-inline-item"><a href="category.html#"><i
                                                            class="fab fa-linkedin-in"></i></a></li>
                                                <li class="list-inline-item"><a href="category.html#"><i
                                                            class="fab fa-pinterest"></i></a></li>
                                                <li class="list-inline-item"><a href="category.html#"><i
                                                            class="fab fa-telegram-plane"></i></a></li>
                                                <li class="list-inline-item"><a href="category.html#"><i
                                                            class="far fa-envelope"></i></a></li>
                                            </ul>
                                        </div>
                                        <div class="more-button float-end">
                                            <a href="blog-single.html"><span class="icon-options"></span></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <h3 class="text-center">No posts found</h3>
                        <?php endif; ?>



                    </div>

                    <?php echo e($posts->links()); ?>

                </div>
                <?php echo $__env->make('layouts.fronendSidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            </div>

        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontendapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mojahid/work-spaces/laravel/creative-it/laravel-project/blog-app/resources/views/frontend/categoryShow.blade.php ENDPATH**/ ?>