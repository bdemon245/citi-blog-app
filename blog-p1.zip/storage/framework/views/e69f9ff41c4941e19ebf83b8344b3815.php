<?php $__env->startSection('backendContent'); ?>
    <div class="row">
        <div class="col-lg-4">
            <?php if(isset($editedCategory)): ?>
                <div class="card">
                    <div class="card-header">Edit Category</div>
                    <div class="card-body">
                        <form action="<?php echo e(route('category.update', $editedCategory)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <input type="text" name="title" class="form-control mb-3 " placeholder="Category Title"
                                value="<?php echo e($editedCategory->title); ?>">
                            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span style="color: red"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <button class="btn btn-primary">Update Category</button>
                        </form>
                    </div>
                </div>
            <?php else: ?>
                <div class="card">
                    <div class="card-header">Add Category</div>
                    <div class="card-body">
                        <form action="/admin/category" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="text" name="title" class="form-control mb-3 " placeholder="Category Title">
                            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span style="color: red"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <button class="btn btn-primary">Add Category</button>
                        </form>
                    </div>
                </div>
            <?php endif; ?>





        </div>
        <div class="col-lg-8">

            <table class="table table-responsive">
                <tr>
                    <th>#</th>
                    <th>Category Title</th>
                    <th>Slug</th>
                    <th>Actions</th>
                </tr>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e(++$key); ?></td>
                        <td><?php echo e($category->title); ?></td>
                        <td><?php echo e($category->slug); ?></td>
                        <td>
                            <div class="btn-group">
                                <a href="<?php echo e(route('category.edit', $category)); ?>" class="btn btn-primary btn-sm">Edit</a>

                                <form action="<?php echo e(route('category.destroy', $category)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                </form>
                            </div>
                        </td>
                    </tr>

                    <?php $__currentLoopData = $category->subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><i data-feather="corner-down-right"></i></td>
                            <td><?php echo e($sub->title); ?></td>
                            <td colspan="2"><?php echo e($sub->slug); ?></td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </table>


        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backendapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mojahid/work-spaces/laravel/creative-it/laravel-project/blog-app/resources/views/backend/category/addCategory.blade.php ENDPATH**/ ?>