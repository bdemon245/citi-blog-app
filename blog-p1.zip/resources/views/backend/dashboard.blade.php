@extends('layouts.backendapp')
@section('backendContent')
<h2>Welcome To Dashboard</h2>
@endsection